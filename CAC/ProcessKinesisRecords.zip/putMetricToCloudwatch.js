var AWS = require('aws-sdk');
var cloudwatch = new AWS.CloudWatch();

exports.handler = (event, context, callback) => {

    //console.log('Received event:', JSON.stringify(event, null, 2));
    
    var warningCount = 0
    event.Records.forEach(function(record) {
        warningCount++;
        // Kinesis data is base64 encoded so decode here
        var payload = new Buffer(record.kinesis.data, 'base64').toString('ascii');
        console.log('Decoded payload:', payload);
        console.log('warning count:', warningCount);

        var params = {
          MetricData: [ /* required */
            {
              MetricName: 'WarningCount', /* required */
              Dimensions: [
                {
                  Name: 'warningID', /* required */
                  Value: '123456' /* required */
                },
                /* more items */
              ],
              Timestamp: event.metadata.reported.status.timestamp,
              Unit: 'None',
              Value: warningCount 
            },
          ],
          Namespace: 'CACDemo' /* required */
        };
        
        cloudwatch.putMetricData(params, function(err, data) {
          var logMsg = 'Count:'+ warningCount+ ' on '+ event.timestamp;
          console.log(logMsg);
          
          context.callbackWaitsForEmptyEventLoop = false; 
          callback(err,data); 
        //   if (err) console.log(err, err.stack); // an error occurred
        //   else     console.log(data);           // successful response
        });

    });
    
    callback(null, 'finished ');
    //context.succeed(logMsg); 
};